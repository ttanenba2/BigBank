package ProgrammingAssignment;

public enum DepositType {
cash, check, mixed
}
