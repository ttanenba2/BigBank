package ProgrammingAssignment;

public enum CheckStatus {
DEPOSITED, RETURNED;
}
