package ProgrammingAssignment;

public enum FEETYPE {
RETURNEDCHECK, OVERDRAFT, LATEPAYMENT
}
