package ProgrammingAssignment;

public enum TransType {
	DEPOSIT, WITHDRAWAL, CHECK, TRANSFER, PLUSADJUSTMENT, MINUSADJUSTMENT, FEE, INTEREST
}
