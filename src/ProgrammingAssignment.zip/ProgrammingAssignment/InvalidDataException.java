package ProgrammingAssignment;
public class InvalidDataException extends RuntimeException {
	public InvalidDataException(String e)
	{
		super(e);
	}
}
