package ProgrammingAssignment;
public class MissingDataException extends RuntimeException {
public MissingDataException(String e)
{
	super(e);
}
}
